var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/football.js
var football_exports = {};
__export(football_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(football_exports);
var handler = async (event) => {
  const endpoint = event.queryStringParameters?.endpoint;
  if (!endpoint) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Missing endpoint parameter" })
    };
  }
  const apiKey = process.env.VITE_API_KEY || process.env.API_KEY;
  const baseUrl = process.env.VITE_API_BASE_URL || "https://v3.football.api-sports.io";
  if (!apiKey) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Missing API key" })
    };
  }
  try {
    const response = await fetch(`${baseUrl}${endpoint}`, {
      headers: {
        "x-apisports-key": apiKey,
        "x-rapidapi-host": "v3.football.api-sports.io"
      }
    });
    const data = await response.json();
    return {
      statusCode: response.ok ? 200 : response.status,
      body: JSON.stringify(
        response.ok ? data : { error: data.errors?.[0] || "API error" }
      )
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Server error", details: err.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=football.js.map
